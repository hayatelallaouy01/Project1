package loginform;


import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.Component;
import java.awt.Container;

public class MenuMaker extends JMenuBar {
	
	private Container container = null;
	
	public MenuMaker(String titles[][]) {
		for (int i=0; i<titles.length; i++) {
			loadMenu(titles[i], null);
		}
	}
	
	public MenuMaker(String titles[][], ActionListener al) {
		for (int i=0; i<titles.length; i++) {
			loadMenu(titles[i], al);
		}
	}
	
	public MenuMaker(String titles[][] , Container c) {
		container = c;
		for (int i=0; i<titles.length; i++) {
			loadMenu(titles[i], null);
		}
	}
	
	public MenuMaker(String titles[][], ActionListener al , Container c) {
		container = c;
		for (int i=0; i<titles.length; i++) {
			loadMenu(titles[i], al);
		}
	}
	
	private void loadMenu(String menu[], ActionListener al) {
		JMenu m;
		if(menu[0].equals("+")){
			if(container != null)m = new LFMenu(container);
			else return;
		}
		else{
			m = new JMenu(menu[0]);
			for (int i=1; i<menu.length; i++) {
				if (menu[i].equals("-")) m.addSeparator();
				else{
					JMenuItem mi = new JMenuItem(menu[i], new ImageIcon("resources/"+menu[i]+".gif"));
					if (al!=null) mi.addActionListener(al);
					m.add(mi);
                                   
                                }}
		}
		this.add(m);
	}
            
        
	public void addActionListener(ActionListener al) {
		for (int i=0; i<getMenuCount(); i++) {
			JMenu m = this.getMenu(i);
			for (int j=0; j<m.getMenuComponentCount(); j++) {
				Component mi = m.getMenuComponent(j);
				if (mi instanceof JMenuItem) ((JMenuItem)mi).addActionListener(al);
			}
		}
	}
}