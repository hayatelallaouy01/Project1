package loginform;


import javax.swing.*;
import java.awt.Container;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.UIManager;
import javax.swing.SwingUtilities;

public class LFMenu extends JMenu implements ActionListener {
	
	Container container;
	UIManager.LookAndFeelInfo LF[];
	public  static  final   String  SKIN="com.birosoft.liquid.LiquidLookAndFeel";   //le skin utilis�
	
	public LFMenu(Container c){
		super("LookAndFeels");
		container = c;
		applySkin(container);
    	LF=UIManager.getInstalledLookAndFeels();
    	try {
		 	UIManager.setLookAndFeel(LF[0].getClassName());
        	SwingUtilities.updateComponentTreeUI(container);
		}
		catch (Exception ex) {
		}
		JRadioButtonMenuItem list[] = new JRadioButtonMenuItem[LF.length];
		for (int i = 0; i<LF.length; i++) {
			list[i] = new JRadioButtonMenuItem(LF[i].getName());
			list[i].addActionListener(this);
			list[i].setActionCommand(""+i);
	    }
	    list[0].setSelected(true);
	    ButtonGroup bg = new ButtonGroup();
	    for (int i = 0; i<list.length; i++) {
	    	bg.add(list[i]);
	    }
	    for (int i = 0; i<list.length; i++) {
	    	this.add(list[i]);
	    }
		/**/
	}
	// throws Exception
	public void actionPerformed(ActionEvent e){
		 JRadioButtonMenuItem src = (JRadioButtonMenuItem)e.getSource();
		 int pos = new Integer(src.getActionCommand()).intValue();
		 try {
		 	UIManager.setLookAndFeel(LF[pos].getClassName());
        	SwingUtilities.updateComponentTreeUI(container);
		 }
		 catch (Exception ex) {
		 }
	}
	
	public  void    applySkin(Container c){
        try{
            UIManager.setLookAndFeel(SKIN);
        	SwingUtilities.updateComponentTreeUI(c);
        }catch(Exception e ){
        	System.out.println ("erruer application skin");
        }
    }
}