package loginform;



import javax.swing.JPanel;
import javax.swing.JInternalFrame;
import java.awt.event.ActionListener;

public class PaneauStage extends JInternalFrame {

	
	public PaneauStage() {
		super("Chercher un stage",true,true,true);
		
	}

	


}


